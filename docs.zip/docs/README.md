# tttienthinh.github.io/AutoStake

### Binance Locked Staking opportunities right out !   
Our BinanceStakeBot notifies you on the Telegram Channel. It constantly analyzes Locked Staking and works 24/7.   

# Service
We wrote code to send requests directly to the Binance database.   
Our bot analyzes the data so that once a staking cryptocurrency is listed, or in the event of a change in APY, you will be notified as soon as possible via the Telegram Channel.   
   
Be careful, the praiseworthy Binance Locked Staking products sell very quickly, hence the aim to get information faster.   


